
from tela_de_login import TelaDeLogin
import sqlite3 as connect

if __name__ == '__main__':

  telalogin = TelaDeLogin()





